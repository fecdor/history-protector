var requireDirectory = require('require-directory')
require('../quick-test')
requireDirectory(module)
