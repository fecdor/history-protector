/* This will test if sleep works. */
var sleep = require('./module')

// console log something
console.log('please wait a moment ...')
// wait 9 seconds
sleep(9000)
// yay!
console.log('Thanks for waiting!')